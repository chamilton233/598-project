# 598-project
To do the citys in multiple places all you have to do is enter it in as Manhattan, Kansas 
TBh it worked when I did the presentation I was just a moron who typed in as Manhattan, ks which does not work 

also Mars insight api is working less and less well. It now only has two days on it so if by the time you grade 
this it says nasa's api is broken I am pretty sure it is broken and not my fault 